package com.vsaytech.mvvmweather.data.model

data class ForecastWS(
    val forecastday: List<ForecastDayWS>
)